
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import javax.swing.table.DefaultTableModel;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author user
 */
public class Update extends javax.swing.JFrame {

    /**
     * Creates new form Update
     */
    public Update() {
        initComponents();
        setTable();
    }
    public void setTable()
    {
        try
        {
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/payrole","root","system");
            PreparedStatement pst = con.prepareStatement("select * from employee");
            ResultSet rs = pst.executeQuery();
            while(rs.next())
            {
                String id = rs.getString("id");
                String name = rs.getString("name");
                String dob = rs.getString("dob");
		String gender = rs.getString("gender");
		String mobileno = rs.getString("mobileno");
		String email = rs.getString("email");
		String address = rs.getString("address");
                String basicsalary = rs.getString("basicsalary");
                String jobtitle = rs.getString("jobtitle");
		
		Object[] obj = {id,name,dob,gender,mobileno,email,address,basicsalary,jobtitle};
		DefaultTableModel model = (DefaultTableModel)emptable.getModel();
		model.addRow(obj);
            }
        }
        catch(Exception e)
        {
	e.printStackTrace();
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        idtxt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        nametxt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        dobtxt = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        mobilenotxt = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        emailtxt = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        addresstxt = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        basicsalarytxt = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jobtitletxt = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        emptable = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        gendercombo = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setText("EMPLOYEE ID");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 50, 100, 40));
        jPanel1.add(idtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 50, 230, 40));

        jLabel4.setText("EMPLOYEE NAME");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, 100, 40));
        jPanel1.add(nametxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, 230, 40));

        jLabel5.setText("DATE OF BIRTH");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, 100, 40));
        jPanel1.add(dobtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 230, 40));

        jLabel6.setText(" GENDER");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 300, 100, 40));

        jLabel7.setText("MOBILE NO");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 100, 40));
        jPanel1.add(mobilenotxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 380, 230, 40));

        jLabel8.setText("E-MAIL");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 460, 100, 40));
        jPanel1.add(emailtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 460, 230, 40));

        addresstxt.setColumns(20);
        addresstxt.setRows(5);
        jScrollPane1.setViewportView(addresstxt);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 530, -1, 100));

        jLabel10.setText("ADDRESS");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 530, 100, 20));

        jLabel2.setText("BASIC SALARY");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 660, 100, 20));
        jPanel1.add(basicsalarytxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 660, 230, 40));

        jLabel9.setText("JOB TITLE");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 750, 100, 20));
        jPanel1.add(jobtitletxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 730, 230, 40));

        emptable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "EMPLOYEE ID", "NAME", "DATE OF BIRTH", "GENDER", "MOBILE NO", "E MAIL", "ADDRESS", "BASIC", "JOB TITLE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        emptable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                emptableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(emptable);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 70, 1130, 590));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("X");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(1550, 0, 60, 50));

        jButton1.setBackground(new java.awt.Color(0, 255, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton1.setText("ADD");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 710, 280, 50));

        jButton2.setBackground(new java.awt.Color(255, 51, 51));
        jButton2.setText("DELETE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 710, 280, 50));

        jButton3.setBackground(new java.awt.Color(51, 102, 255));
        jButton3.setText("UPDATE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 710, 280, 50));

        gendercombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female", "Others" }));
        jPanel1.add(gendercombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 300, 230, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1610, 840));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        this.dispose();
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String id = idtxt.getText();
        String name = nametxt.getText();
        String dob = dobtxt.getText();
        String gender = (String) gendercombo.getSelectedItem();
        String mobileno = mobilenotxt.getText();
        String email = emailtxt.getText();
        String address = addresstxt.getText();
        String basicsalary = basicsalarytxt.getText();
        String jobtitle = jobtitletxt.getText();
        try
        {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/payrole","root","system");
            PreparedStatement pst  = con.prepareStatement("insert into employee values(?,?,?,?,?,?,?,?,?)");
            pst.setString(1, id);
            pst.setString(2, name);
            pst.setString(3, dob);
            pst.setString(4, gender);
            pst.setString(5, mobileno);
            pst.setString(6, email);
            pst.setString(7, address);
            pst.setString(8, basicsalary);
            pst.setString(9, jobtitle);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"EMPLOYEE ADDED SUCCESSFULLY");
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,"EMPLOYEE ADDITION FAILED");
        }
        DefaultTableModel model = (DefaultTableModel)emptable.getModel();
        model.setRowCount(0);
        setTable();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        String id = idtxt.getText();
        String name = nametxt.getText();
        String dob = dobtxt.getText();
        String gender = (String) gendercombo.getSelectedItem();
        String mobileno = mobilenotxt.getText();
        String email = emailtxt.getText();
        String address = addresstxt.getText();
        String basicsalary = basicsalarytxt.getText();
        String jobtitle = jobtitletxt.getText();
        try
        {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/payrole","root","system");
            PreparedStatement pst  = con.prepareStatement("update employee set name=?,dob=?,gender=?,mobileno=?,email=?,address=?, basicsalary=?,JOBTITLE=? where id=?");
            pst.setString(9, id);
            pst.setString(1, name);
            pst.setString(2, dob);
            pst.setString(3, gender);
            pst.setString(4, mobileno);
            pst.setString(5, email);
            pst.setString(6, address);
            pst.setString(7, basicsalary);
            pst.setString(8, jobtitle);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"EMPLOYEE DETAILS UPDATED SUCCESSFULLY");
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,"EMPLOYEE DETAILS UPDATION FAILED");
        }
        DefaultTableModel model = (DefaultTableModel)emptable.getModel();
        model.setRowCount(0);
        setTable();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String id = idtxt.getText();
        try
        {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/payrole","root","system");
            PreparedStatement pst  = con.prepareStatement("delete from employee where id=?");
            pst.setString(1, id);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"EMPLOYEE DELETED SUCCESSFULLY");
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,"EMPLOYEE DELETION FAILED");
        }
        DefaultTableModel model = (DefaultTableModel)emptable.getModel();
        model.setRowCount(0);
        setTable();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void emptableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_emptableMouseClicked
        int row = emptable.getSelectedRow();
        TableModel model = emptable.getModel();
        idtxt.setText(model.getValueAt(row, 0).toString());
        nametxt.setText(model.getValueAt(row, 1).toString());
        dobtxt.setText(model.getValueAt(row, 2).toString());
        gendercombo.setSelectedItem(model.getValueAt(row, 3));
        mobilenotxt.setText(model.getValueAt(row, 4).toString());
        emailtxt.setText(model.getValueAt(row, 5).toString());
        addresstxt.setText(model.getValueAt(row, 6).toString());
        basicsalarytxt.setText(model.getValueAt(row, 7).toString());
        jobtitletxt.setText(model.getValueAt(row, 8).toString());
    }//GEN-LAST:event_emptableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Update().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea addresstxt;
    private javax.swing.JTextField basicsalarytxt;
    private javax.swing.JTextField dobtxt;
    private javax.swing.JTextField emailtxt;
    private javax.swing.JTable emptable;
    private javax.swing.JComboBox<String> gendercombo;
    private javax.swing.JTextField idtxt;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jobtitletxt;
    private javax.swing.JTextField mobilenotxt;
    private javax.swing.JTextField nametxt;
    // End of variables declaration//GEN-END:variables
}
