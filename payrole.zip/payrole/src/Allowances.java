import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import javax.swing.table.DefaultTableModel;
public class Allowances extends javax.swing.JFrame {

    /**
     * Creates new form Allowances
     */
    public Allowances() {
        initComponents();
        setTable();
    }
 public void setTable()
    {
        try
        {
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/payrole","root","system");
            PreparedStatement pst = con.prepareStatement("select * from allowance");
            ResultSet rs = pst.executeQuery();
            while(rs.next())
            {
                String id = rs.getString("id");
                String name = rs.getString("name");
                String basicsalary = rs.getString("basicsalary");
		String overtime = rs.getString("overtime");
		String medical = rs.getString("medical");
		String bonus= rs.getString("bonus");
		String others = rs.getString("others");
                String tax = rs.getString("tax");
                String total = rs.getString("total");
                		
		Object[] obj = {id,name,basicsalary,overtime,medical,bonus,others,tax,total};
		DefaultTableModel model = (DefaultTableModel)allowancetable.getModel();
		model.addRow(obj);
            }
        }
        catch(Exception e)
        {
	e.printStackTrace();
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        idtxt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        nametxt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        dobtxt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        basicsalarytxt = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        medicaltxt = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        overtimetxt = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        bonustxt = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        totaltxt = new javax.swing.JFormattedTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        allowancetable = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        otherstxt = new javax.swing.JTextField();
        taxtxt = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setText("ALLOWANCES");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 270, 60));

        jLabel3.setText("EMPLOYEE ID");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 100, 40));
        jPanel1.add(idtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 80, 260, 40));

        jLabel4.setText("EMPLOYEE NAME");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, 130, 40));
        jPanel1.add(nametxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 260, 40));

        jLabel5.setText("DATE OF BIRTH");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 130, 40));
        jPanel1.add(dobtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 240, 260, 40));

        jLabel2.setText("MEDICAL");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 120, 90, 30));
        jPanel1.add(basicsalarytxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 320, 260, 40));

        jButton1.setBackground(new java.awt.Color(51, 255, 51));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("FIND");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 80, -1, 30));
        jPanel1.add(medicaltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 120, 80, 30));

        jLabel6.setText("BASIC SALARY");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, 130, 20));

        jLabel7.setText("OVERTIME");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 70, 90, 30));
        jPanel1.add(overtimetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 70, 80, 30));

        jLabel8.setText("BONUS");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 170, 90, 30));
        jPanel1.add(bonustxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 170, 80, 30));

        jLabel10.setText("OTHERS");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 230, 90, 30));

        jButton2.setBackground(new java.awt.Color(255, 51, 51));
        jButton2.setText("CLEAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 270, 230, 40));

        jButton3.setBackground(new java.awt.Color(153, 255, 102));
        jButton3.setText("SAVE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 200, 230, 40));

        jButton4.setBackground(new java.awt.Color(0, 51, 255));
        jButton4.setText("CALCULATE TOTAL");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 120, 230, 40));

        jLabel11.setText("TAX");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 270, 90, 30));

        totaltxt.setEditable(false);
        totaltxt.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));
        jPanel1.add(totaltxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 320, 80, 30));

        allowancetable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "EMPLOYEE ID", "EMPLOYEE NAME", "BASIC SALARY", "OVERTIME", "MEDICAL", "BONUS", "OTHERS", "TOTAL"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(allowancetable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 420, 1240, 290));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("X");
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(1347, 0, 50, 50));

        jLabel12.setText("TOTAL");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 320, 90, 30));
        jPanel1.add(otherstxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 230, 80, 30));

        taxtxt.setEditable(false);
        taxtxt.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));
        jPanel1.add(taxtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 270, 80, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1400, 750));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        String id= idtxt.getText();
        String name= nametxt.getText();
        String salary= basicsalarytxt.getText();
        String overtime= overtimetxt.getText();
        String medical= medicaltxt.getText();
        String bonus= bonustxt.getText();
        String others= taxtxt.getText();
        String tax=taxtxt.getText();
        String total= totaltxt.getText();
        try
        {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/payrole","root","system");
            PreparedStatement pst = con.prepareStatement("insert into allowance values (?,?,?,?,?,?,?,?,?)");
            pst.setString(1, id);
            pst.setString(2, name);
            pst.setString(3, salary);
            pst.setString(4, overtime);
            pst.setString(5, medical);
            pst.setString(6, bonus);
            pst.setString(7, others);
            pst.setString(8, tax);
            pst.setString(9, total);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"Allowances Added Successfully");
        }
        catch(Exception e)
        {
            e.printStackTrace();
             JOptionPane.showMessageDialog(null,"Allowances Addition Failed");
        }
        DefaultTableModel model = (DefaultTableModel)allowancetable.getModel();
        model.setRowCount(0);
        setTable();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        float overtime=Float.parseFloat(overtimetxt.getText());
        float medical=Float.parseFloat(medicaltxt.getText());
        float bonus=Float.parseFloat(bonustxt.getText());
        float others=Float.parseFloat(otherstxt.getText());
        float basicsalary =Float.parseFloat(basicsalarytxt.getText());
        float total =medical+overtime+bonus+others+basicsalary;
        float tax=((total*5)/100);
        taxtxt.setValue(tax);
        totaltxt.setValue(total);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String id = idtxt.getText();
        try
        {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/payrole","root","system");
            PreparedStatement pst = con.prepareStatement("select * from employee where id=?");
            pst.setString(1, id);
            ResultSet rs = pst.executeQuery();
            while(rs.next())
            {
                nametxt.setText(rs.getString("name"));
                dobtxt.setText(rs.getString("dob"));
                basicsalarytxt.setText(rs.getString("basicsalary"));
            }
            if(nametxt.getText().equals(""))
                JOptionPane.showMessageDialog(null, "NO EMPLOYEE FOUND");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
           this.dispose();
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        idtxt.setText("");
        nametxt.setText("");
        dobtxt.setText("");
        basicsalarytxt.setText("");
        overtimetxt.setText("");
        medicaltxt.setText("");
        bonustxt.setText("");
        taxtxt.setText("");
        totaltxt.setText("");
        otherstxt.setText("");
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Allowances.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Allowances.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Allowances.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Allowances.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Allowances().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable allowancetable;
    private javax.swing.JTextField basicsalarytxt;
    private javax.swing.JTextField bonustxt;
    private javax.swing.JTextField dobtxt;
    private javax.swing.JTextField idtxt;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField medicaltxt;
    private javax.swing.JTextField nametxt;
    private javax.swing.JTextField otherstxt;
    private javax.swing.JTextField overtimetxt;
    private javax.swing.JFormattedTextField taxtxt;
    private javax.swing.JFormattedTextField totaltxt;
    // End of variables declaration//GEN-END:variables
}
